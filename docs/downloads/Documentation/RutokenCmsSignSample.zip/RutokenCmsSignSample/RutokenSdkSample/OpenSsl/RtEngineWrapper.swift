//
//  RtEngineWrapper.swift
//  RutokenSdkSample
//
//  Created by Vova Badyaev on 25.03.25.
//

class RtEngineWrapper: @unchecked Sendable {
    private let rtengine: OpaquePointer

    init() {
        let ENGINE_METHOD_ALL: UInt32 = 0xFFFF
        let ENGINE_METHOD_RAND: UInt32 = 0x0008

        var rv = rt_eng_load_engine()
        assert(rv == 1)

        rtengine = rt_eng_get0_engine()
        ENGINE_init(rtengine)
        rv = ENGINE_set_default(rtengine, ENGINE_METHOD_ALL - ENGINE_METHOD_RAND)
        assert(rv == 1)
    }

    deinit {
        ENGINE_unregister_pkey_asn1_meths(rtengine)
        ENGINE_unregister_pkey_meths(rtengine)
        ENGINE_unregister_digests(rtengine)
        ENGINE_unregister_ciphers(rtengine)
        ENGINE_finish(rtengine)

        rt_eng_unload_engine()
    }
}

//
//  OpenSslWrapper.swift
//  RutokenSdkSample
//
//  Created by Vova Badyaev on 25.03.25.
//

class OpenSslWrapper {
    init() {
        let result = OPENSSL_init_crypto(UInt64(OPENSSL_INIT_NO_LOAD_CONFIG | OPENSSL_INIT_NO_ATEXIT), nil)
        assert(result == 1)
    }

    deinit {
        OPENSSL_cleanup()
    }
}

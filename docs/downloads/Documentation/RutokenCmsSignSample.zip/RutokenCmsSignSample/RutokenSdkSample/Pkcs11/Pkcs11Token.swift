//
//  Pkcs11Token.swift
//  RutokenSdkSample
//
//  Created by Усман Туркаев on 27.01.2025.
//

import Foundation

struct Pkcs11Token: Identifiable, Equatable {
    private let session: Pkcs11Session
    private let engine: RtEngineWrapper

    let label: String
    let serial: String
    let slot: CK_SLOT_ID

    var id: String {
        serial
    }

    init(with slot: CK_SLOT_ID, engine: RtEngineWrapper) async throws(Pkcs11Error) {
        self.slot = slot
        self.engine = engine

        var tokenInfo = CK_TOKEN_INFO()
        let rv = await Pkcs11.GetTokenInfo(slot, &tokenInfo)
        guard rv == CKR_OK else {
            throw .error(rv: rv)
        }

        guard let hexSerial = String(bytes: Array(withUnsafeBytes(of: tokenInfo.serialNumber) { [UInt8]($0)}), encoding: .utf8),
              let decimalSerial = Int(hexSerial.trimmingCharacters(in: .whitespacesAndNewlines), radix: 16) else {
            throw .error()
        }

        self.serial = String(format: "%0.10d", decimalSerial)

        guard let label = String(bytes: Array(withUnsafeBytes(of: tokenInfo.label) { [UInt8]($0)}), encoding: .utf8)?
            .trimmingCharacters(in: .whitespacesAndNewlines) else {
            throw .error()
        }
        self.label = label

        self.session = try await Pkcs11Session(slot: self.slot)
    }

    func login(with pin: String) async throws(Pkcs11Error) {
        try await session.login(pin: pin)
    }

    func logout() async {
        await session.logout()
    }

    func generateKeyPair(keyId: Data, label: Data) async throws {
        try await session.generateKeyPair(keyId: keyId, label: label)
    }

    func enumerateKeys() async throws -> [Pkcs11KeyPair] {
        let publicKeys = try await Pkcs11Template.makePubKeyBaseTemplate()
            .withCkTemplate {
                 try await session.findObjects($0) as [Pkcs11Object]
            }

        let privateKeys = try await Pkcs11Template.makePrivKeyBaseTemplate()
            .withCkTemplate {
                 try await session.findObjects($0) as [Pkcs11Object]
            }

        var pairs: [Pkcs11KeyPair] = []
        for privateKey in privateKeys {
            let privateKeyId = try await privateKey.getValue(forAttr: .id)
            let privateKeyLabel = try await privateKey.getValue(forAttr: .label)
            for publicKey in publicKeys {
                if try await privateKeyId == publicKey.getValue(forAttr: .id),
                   let id = String(data: privateKeyId, encoding: .utf8),
                   let label = String(data: privateKeyLabel, encoding: .utf8) {
                    pairs.append(Pkcs11KeyPair(publicKey: publicKey,
                                               privateKey: privateKey,
                                               id: id, label: label))
                    break
                }
            }
        }
        return pairs
    }

    static func == (lhs: Pkcs11Token, rhs: Pkcs11Token) -> Bool {
        return lhs.serial == rhs.serial
    }
}

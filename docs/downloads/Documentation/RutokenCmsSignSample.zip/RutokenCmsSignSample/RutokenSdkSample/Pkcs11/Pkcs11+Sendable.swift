//
//  Pkcs11+Sendable.swift
//  RutokenSdkSample
//
//  Created by Vova Badyaev on 03.04.25.
//

extension CK_MECHANISM: @unchecked Sendable {}

//
//  Pkcs11Session.swift
//  Rutoken Pass
//
//  Created by Никита Девятых on 14.10.2024.
//

import Foundation

struct Pkcs11Session {
    private var handle = CK_SESSION_HANDLE(NULL_PTR)

    init(slot: CK_SLOT_ID) async throws(Pkcs11Error) {
        let rv = await Pkcs11.OpenSession(slot,
                               CK_FLAGS(CKF_SERIAL_SESSION | CKF_RW_SESSION),
                               nil,
                               nil,
                               &self.handle)
        guard rv == CKR_OK else {
            throw .error(rv: rv)
        }
    }

    func login(pin: String) async throws(Pkcs11Error) {
        var rawPin: [UInt8] = Array(pin.utf8)
        let rv = await Pkcs11.Login(handle, CK_USER_TYPE(CKU_USER), &rawPin, CK_ULONG(rawPin.count))
        guard rv == CKR_OK || rv == CKR_USER_ALREADY_LOGGED_IN else {
            throw .error(rv: rv)
        }
    }

    func logout() async {
        await Pkcs11.Logout(handle)
    }

    func findObjects(_ attributes: [CK_ATTRIBUTE]) async throws(Pkcs11Error) -> [Pkcs11Object] {
        var template = attributes
        var rv = await Pkcs11.FindObjectsInit(handle, &template, CK_ULONG(template.count))
        guard rv == CKR_OK else {
            throw .error(rv: rv)
        }

        var count: CK_ULONG = 0
        let maxCount: CK_ULONG = 16
        var objects: [CK_OBJECT_HANDLE] = []
        repeat {
            var handles: [CK_OBJECT_HANDLE] = Array(repeating: 0x00, count: Int(maxCount))

            rv = await Pkcs11.FindObjects(handle, &handles, maxCount, &count)
            guard rv == CKR_OK else {
                await Pkcs11.FindObjectsFinal(handle)
                throw .error(rv: rv)
            }

            objects += handles.prefix(Int(count))
        } while count == maxCount

        await Pkcs11.FindObjectsFinal(handle)
        return objects.map { Pkcs11Object(with: $0, handle) }
    }

    func generateKeyPair(keyId: Data, label: Data) async throws {
        var publicKey = CK_OBJECT_HANDLE()
        var privateKey = CK_OBJECT_HANDLE()

        let currentDate = Date()
        var startDateData = Pkcs11Date(date: currentDate)
        var endDateData = Pkcs11Date(date: currentDate.addingTimeInterval(3 * 365 * 24 * 60 * 60))

        let publicKeyTemplate = Pkcs11Template.makePubKeyBaseTemplate()
            .add(attr: .id, value: keyId)
            .add(attr: .label, value: label)
            .add(attr: .keyType, value: CKK_GOSTR3410)
            .add(attr: .startDate, value: startDateData.data())
            .add(attr: .endDate, value: endDateData.data())
            .add(attr: .gostR3410Params, value: Data(Pkcs11Constants.gostR3410_2012_256_paramset_B))
            .add(attr: .gostR3411Params, value: Data(Pkcs11Constants.gostR3411_2012_256_params_oid))

        let privateKeyTemplate = Pkcs11Template.makePrivKeyBaseTemplate()
            .add(attr: .id, value: keyId)
            .add(attr: .label, value: label)
            .add(attr: .keyType, value: CKK_GOSTR3410)
            .add(attr: .derive, value: true)
            .add(attr: .startDate, value: startDateData.data())
            .add(attr: .endDate, value: endDateData.data())
            .add(attr: .gostR3410Params, value: Data(Pkcs11Constants.gostR3410_2012_256_paramset_B))
            .add(attr: .gostR3411Params, value: Data(Pkcs11Constants.gostR3411_2012_256_params_oid))

        var gostR3410_2012_256KeyPairGenMech: CK_MECHANISM = CK_MECHANISM(mechanism: CKM_GOSTR3410_KEY_PAIR_GEN, pParameter: nil, ulParameterLen: 0)

        try await publicKeyTemplate.withCkTemplate { pubCkTemplate in
            try await privateKeyTemplate.withCkTemplate { prvCkTemplate in
                let rv = await Pkcs11.GenerateKeyPair(handle, &gostR3410_2012_256KeyPairGenMech,
                                           &pubCkTemplate, CK_ULONG(pubCkTemplate.count),
                                           &prvCkTemplate, CK_ULONG(prvCkTemplate.count),
                                           &publicKey, &privateKey)
                guard rv == CKR_OK else {
                    throw Pkcs11Error.error(rv: rv)
                }
            }
        }
    }
}

//
//  RutokenSdkSample-Bridging-Header.h
//  RutokenSdkSample
//
//  Created by Никита Девятых on 17.01.2025.
//

#ifndef RutokenSdkSample_Bridging_Header_h
#define RutokenSdkSample_Bridging_Header_h

#include <rtpkcs11ecp/rtpkcs11.h>
#include <rtpkcs11ecp/cryptoki.h>

#include <openssl/configuration.h>
#undef OPENSSL_NO_DEPRECATED
#define OPENSSL_SUPPRESS_DEPRECATED

#include <rtengine/engine.h>

#endif /* RutokenSdkSample_Bridging_Header_h */

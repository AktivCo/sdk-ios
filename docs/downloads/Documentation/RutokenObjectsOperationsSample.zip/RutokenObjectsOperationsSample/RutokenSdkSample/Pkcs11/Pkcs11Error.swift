//
//  Pkcs11Error.swift
//  RutokenSdkSample
//
//  Created by Усман Туркаев on 01.02.2025.
//

import Foundation

enum Pkcs11Error: Error, Equatable {
    case internalError(func: String = #function, line: UInt = #line, rv: UInt? = nil)
    
    var description: String {
        switch self {
        case .internalError(let funcName, let line, let rv):
            return "\(funcName):\(line)\(rv.map { String(format: ":0x%02X", $0) } ?? "")"
        }
    }
}

//
//  Pkcs11Token.swift
//  RutokenSdkSample
//
//  Created by Усман Туркаев on 27.01.2025.
//

import Foundation

struct Pkcs11Token: Identifiable {
    let label: String
    let serial: String

    var id: String {
        serial
    }

    init(with slot: CK_SLOT_ID) async throws(Pkcs11Error) {
        var tokenInfo = CK_TOKEN_INFO()
        let rv = await Pkcs11.GetTokenInfo(slot, &tokenInfo)
        guard rv == CKR_OK else {
            throw Pkcs11Error.internalError(rv: rv)
        }

        guard let hexSerial = String(bytes: Array(withUnsafeBytes(of: tokenInfo.serialNumber) { [UInt8]($0)}), encoding: .utf8),
              let decimalSerial = Int(hexSerial.trimmingCharacters(in: .whitespacesAndNewlines), radix: 16) else {
            throw Pkcs11Error.internalError()
        }

        self.serial = String(format: "%0.10d", decimalSerial)

        guard let label = String(bytes: Array(withUnsafeBytes(of: tokenInfo.label) { [UInt8]($0)}), encoding: .utf8)?
            .trimmingCharacters(in: .whitespacesAndNewlines) else {
            throw Pkcs11Error.internalError()
        }
        self.label = label
    }
}

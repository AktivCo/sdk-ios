//
//  Pkcs11Actor.swift
//  RutokenSdkSample
//
//  Created by Усман Туркаев on 24.01.2025.
//

@globalActor actor WfseActor: GlobalActor {
    static let shared = WfseActor()
}

@globalActor actor Pkcs11Actor: GlobalActor {
    static let shared = Pkcs11Actor()
}

struct Pkcs11 {
    private init() {}

    @discardableResult
    @WfseActor static func WaitForSlotEvent(_ flags: CK_FLAGS,
                                            _ pSlot: CK_SLOT_ID_PTR!,
                                            _ pReserved: CK_VOID_PTR!) -> CK_RV {
        return C_WaitForSlotEvent(flags, pSlot, pReserved)
    }

    @discardableResult
    @Pkcs11Actor static func Initialize(_ pInitArgs: CK_VOID_PTR!) -> CK_RV {
        return C_Initialize(pInitArgs)
    }

    @discardableResult
    @Pkcs11Actor static func Finalize(_ pReserved: CK_VOID_PTR!) -> CK_RV {
        return C_Finalize(pReserved)
    }

    @discardableResult
    @Pkcs11Actor static func GetSlotList(_ tokenPresent: CK_BBOOL,
                                         _ pSlotList: CK_SLOT_ID_PTR!,
                                         _ pulCount: CK_ULONG_PTR!) -> CK_RV {
        return C_GetSlotList(tokenPresent, pSlotList, pulCount)
    }

    @discardableResult
    @Pkcs11Actor static func GetSlotInfo(_ slotID: CK_SLOT_ID,
                                         _ pInfo: CK_SLOT_INFO_PTR!) -> CK_RV {
        return C_GetSlotInfo(slotID, pInfo)
    }

    @discardableResult
    @Pkcs11Actor static func GetTokenInfo(_ slotID: CK_SLOT_ID,
                                          _ pInfo: CK_TOKEN_INFO_PTR!) -> CK_RV {
        return C_GetTokenInfo(slotID, pInfo)
    }
}

//
//  ContentView.swift
//  RutokenSdkSample
//
//  Created by Никита Девятых on 17.01.2025.
//

import SwiftUI

struct MainView: View {
    @StateObject var viewModel = MainViewModel()

    var body: some View {
        NavigationStack {
            VStack {
                List {
                    ForEach(Array(viewModel.tokens.values)) { token in
                        TokenView(token: token)
                    }
                }
                .scrollContentBackground(.hidden)
                Button {
                    if viewModel.isMonitoringEnabled {
                        viewModel.stopMonitoring()
                    } else {
                        viewModel.startMonitoring()
                    }
                } label: {
                    Text(viewModel.isMonitoringEnabled ? "Остановить поиск" : "Начать поиск")
                        .animation(nil)
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .frame(height: 40)
                }
                .buttonStyle(.borderedProminent)
                .padding()
            }
            .navigationTitle("Рутокены")
            .background(.gray.opacity(0.1))
        }
        .alert(viewModel.errorText ?? "",
               isPresented: Binding(get: { viewModel.errorText != nil },
                                    set: { if !$0 { viewModel.setError(nil) } })) {
            Button("OK", role: .cancel) { viewModel.setError(nil) }
        }
    }
}

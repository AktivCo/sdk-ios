//
//  TokenView.swift
//  RutokenSdkSample
//
//  Created by Усман Туркаев on 27.01.2025.
//

import SwiftUI

struct TokenView: View {
    var token: Pkcs11Token

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text("Имя токена")
                .foregroundStyle(.secondary)
                .font(.subheadline)
            Text(token.label)
            Text("Серийный номер")
                .foregroundStyle(.secondary)
                .font(.subheadline)
            Text(token.serial)
        }
    }
}

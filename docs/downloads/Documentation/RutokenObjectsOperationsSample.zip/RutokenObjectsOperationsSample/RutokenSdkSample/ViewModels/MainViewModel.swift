//
//  MainViewModel.swift
//  RutokenSdkSample
//
//  Created by Никита Девятых on 17.01.2025.
//

import Foundation

final actor MainViewModel: ObservableObject {
    @MainActor @Published private(set) var tokens: [CK_SLOT_ID: Pkcs11Token] = [:]
    @MainActor @Published private(set) var errorText: String?
    @MainActor @Published private(set) var isMonitoringEnabled: Bool = false

    @MainActor func startMonitoring() {
        guard !isMonitoringEnabled else { return }
        isMonitoringEnabled = true
        Task.detached {
            do {
                var initArgs = CK_C_INITIALIZE_ARGS()
                initArgs.flags = UInt(CKF_OS_LOCKING_OK)

                var rv = await Pkcs11.Initialize(&initArgs)
                guard rv == CKR_OK else {
                    throw Pkcs11Error.internalError(rv: rv)
                }

                var ctr: UInt = 0
                rv = await Pkcs11.GetSlotList(CK_BBOOL(CK_TRUE), nil, &ctr)
                guard rv == CKR_OK else {
                    throw Pkcs11Error.internalError(rv: rv)
                }

                if ctr != 0 {
                    var slots: [CK_SLOT_ID]
                    repeat {
                        slots = Array(repeating: CK_SLOT_ID(0), count: Int(ctr))
                        rv = await Pkcs11.GetSlotList(CK_BBOOL(CK_TRUE), &slots, &ctr)
                    } while rv == CKR_BUFFER_TOO_SMALL

                    guard rv == CKR_OK else {
                        throw Pkcs11Error.internalError(rv: rv)
                    }
                    
                    for i in 0..<Int(ctr) where try await self.isPresent(slots[i]) {
                        let token = try await Pkcs11Token(with: slots[i])
                        await self.setAvailableToken(for: slots[i], token)
                    }
                }
            } catch let error as Pkcs11Error {
                await self.setError(error)
            }

            while true {
                var slot = CK_SLOT_ID()
                let rv = await Pkcs11.WaitForSlotEvent(0, &slot, nil)
                guard rv != CKR_CRYPTOKI_NOT_INITIALIZED else {
                    break
                }
                guard rv == CKR_OK else { continue }

                do {
                    if try await self.isPresent(slot) {
                        let token = try await Pkcs11Token(with: slot)
                        await self.setAvailableToken(for: slot, token)
                    } else {
                        await self.setAvailableToken(for: slot, nil)
                    }
                } catch let error as Pkcs11Error {
                    await self.setError(error)
                }
            }
        }
    }

    @MainActor func stopMonitoring() {
        guard isMonitoringEnabled else { return }
        isMonitoringEnabled = false
        tokens.removeAll()
        Task.detached {
            await Pkcs11.Finalize(nil)
        }
    }

    @MainActor func setError(_ error: Pkcs11Error?) {
        self.errorText = error?.description
    }

    @MainActor private func setAvailableToken(for slot: CK_SLOT_ID, _ value: Pkcs11Token?) {
        self.tokens[slot] = value
    }

    private func isPresent(_ slot: CK_SLOT_ID) async throws(Pkcs11Error) -> Bool {
        var slotInfo = CK_SLOT_INFO()
        let rv = await Pkcs11.GetSlotInfo(slot, &slotInfo)
        guard rv == CKR_OK else {
            throw Pkcs11Error.internalError(rv: rv)
        }
        return slotInfo.flags & UInt(CKF_TOKEN_PRESENT) != 0
    }
}

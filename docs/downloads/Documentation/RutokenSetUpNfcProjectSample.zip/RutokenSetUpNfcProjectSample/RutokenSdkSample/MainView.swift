//
//  ContentView.swift
//  RutokenSdkSample
//
//  Created by Никита Девятых on 17.01.2025.
//

import SwiftUI

struct MainView: View {
    @StateObject var viewModel: MainViewModel = MainViewModel()

    var body: some View {
        VStack(spacing: 10) {
            Text("Видно токенов: \(viewModel.numberOfSlots)")
            Button("Начать проверку") {
                viewModel.startApp()
            }
            .buttonStyle(.bordered)
            if let error = viewModel.errorText {
                Text(error)
            }
        }
        .padding()
    }
}

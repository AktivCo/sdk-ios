//
//  MainViewModel.swift
//  RutokenSdkSample
//
//  Created by Никита Девятых on 17.01.2025.
//

import Foundation

class MainViewModel: ObservableObject {
    @Published var numberOfSlots: Int = 0
    @Published var errorText: String?

    func startApp() {
        var initArgs = CK_C_INITIALIZE_ARGS()
        initArgs.flags = UInt(CKF_OS_LOCKING_OK)

        var rv = C_Initialize(&initArgs)
        guard rv == CKR_OK else {
            errorText = "Произошла ошибка Pkcs: код \(rv)"
            return
        }

        var ctr: UInt = 0
        rv = C_GetSlotList(CK_BBOOL(CK_TRUE), nil, &ctr)
        guard rv == CKR_OK else {
            errorText = "Произошла ошибка Pkcs: код \(rv)"
            return
        }

        numberOfSlots = Int(ctr)
        rv = C_Finalize(nil)
        guard rv == CKR_OK else {
            errorText = "Произошла ошибка Pkcs: код \(rv)"
            return
        }
    }
}

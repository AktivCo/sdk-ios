//
//  TokenViewModel.swift
//  RutokenSdkSample
//
//  Created by Усман Туркаев on 21.02.2025.
//

import Foundation

final actor TokenViewModel: ObservableObject {
    @MainActor let token: Pkcs11Token
    @MainActor @Published private(set) var errorText: String?
    @MainActor @Published private(set) var keyPairs: [Pkcs11KeyPair]?

    init(token: Pkcs11Token) {
        self.token = token
    }

    @MainActor func enumerateKeys(pin: String) {
        Task.detached {
            do {
                try await self.token.login(with: pin)
                await self.setKeyPairs(try await self.token.enumerateKeys())
            } catch let error as Pkcs11Error {
                await self.setError(error)
            }
        }
    }

    @MainActor func generateKeyPair(label: String) {
        let keyId = Data(UUID().uuidString.utf8)
        let label = Data(label.utf8)
        Task.detached {
            do {
                try await self.token.generateKeyPair(keyId: keyId, label: label)
                await self.setKeyPairs(try await self.token.enumerateKeys())
            } catch let error as Pkcs11Error {
                await self.setError(error)
            }
        }
    }

    @MainActor func setError(_ error: Pkcs11Error?) {
        errorText = error?.description
    }

    @MainActor func deleteKeyPair(at indexes: IndexSet) {
        Task.detached {
            do {
                guard var keys = await self.keyPairs else { return }
                for index in indexes {
                    try await keys[index].delete()
                }
                keys.remove(atOffsets: indexes)
                await self.setKeyPairs(keys)
            } catch let error as Pkcs11Error {
                await self.setError(error)
            }
        }
    }

    @MainActor private func setKeyPairs(_ value: [Pkcs11KeyPair]) {
        keyPairs = value
    }
}

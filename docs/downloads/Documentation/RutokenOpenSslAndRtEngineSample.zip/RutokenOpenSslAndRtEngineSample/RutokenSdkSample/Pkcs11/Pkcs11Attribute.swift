//
//  Pkcs11Attribute.swift
//  Rutoken Pass
//
//  Created by Никита Девятых on 14.10.2024.
//

enum Pkcs11BoolAttribute {
    case token
    case derive
    case privateness

    var type: CK_ULONG {
        switch self {
        case .token: return CKA_TOKEN
        case .derive: return CKA_DERIVE
        case .privateness: return CKA_PRIVATE
        }
    }
}

enum Pkcs11CkUlongAttribute {
    case classObject
    case keyType

    var type: CK_ULONG {
        switch self {
        case .classObject: return CKA_CLASS
        case .keyType: return CKA_KEY_TYPE
        }
    }
}

enum Pkcs11DataAttribute {
    case id
    case label
    case value
    case gostR3410Params
    case gostR3411Params
    case startDate
    case endDate

    var type: CK_ULONG {
        switch self {
        case .id: return CKA_ID
        case .label: return CKA_LABEL
        case .value: return CKA_VALUE
        case .gostR3410Params: return CKA_GOSTR3410_PARAMS
        case .gostR3411Params: return CKA_GOSTR3411_PARAMS
        case .startDate: return CKA_START_DATE
        case .endDate: return CKA_END_DATE
        }
    }
}

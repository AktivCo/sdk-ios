//
//  Pkcs11KeyPair.swift
//  Rutoken Tech
//
//  Created by Андрей Трифонов on 2024-05-27.
//

struct Pkcs11KeyPair: Identifiable {
    let publicKey: Pkcs11Object
    let privateKey: Pkcs11Object
    let id: String
    let label: String

    func delete() async throws {
        try await publicKey.delete()
        try await privateKey.delete()
    }
}

//
//  Pkcs11Date.swift
//  Rutoken Tech
//
//  Created by Андрей Трифонов on 2024-05-27.
//

import Foundation

struct Pkcs11Date {
    var date: CK_DATE

    init(date: Date) {
        let day = date.getString(as: "dd").compactMap { $0.asciiValue }
        let month = date.getString(as: "MM").compactMap { $0.asciiValue }
        let year = date.getString(as: "YYYY").compactMap { $0.asciiValue }

        self.date = CK_DATE()
        self.date.day = (day[0], day[1])
        self.date.month = (month[0], month[1])
        self.date.year = (year[0], year[1], year[2], year[3])
    }

    mutating func data() -> Data {
        return Data(bytes: &date, count: 8)
    }
}

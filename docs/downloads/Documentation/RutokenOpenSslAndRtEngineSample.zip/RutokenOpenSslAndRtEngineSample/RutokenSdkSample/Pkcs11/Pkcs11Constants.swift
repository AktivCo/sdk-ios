//
//  Pkcs11Constants.swift
//  Rutoken Pass
//
//  Created by Никита Девятых on 23.10.2024.
//

enum Pkcs11Constants {
    // Набор параметров КриптоПро A алгоритма ГОСТ Р 34.10-2012 для ключа длиной 256
    static let gostR3410_2012_256_paramset_B: [CK_BYTE] = [ 0x06, 0x09, 0x2A, 0x85, 0x03, 0x07, 0x01, 0x02, 0x01, 0x01, 0x02 ]
    // Набор параметров КриптоПро алгоритма ГОСТ Р 34.11-2012 для ключа длиной 256
    static let gostR3411_2012_256_params_oid: [CK_BYTE] = [ 0x06, 0x08, 0x2a, 0x85, 0x03, 0x07, 0x01, 0x01, 0x02, 0x02 ]
}

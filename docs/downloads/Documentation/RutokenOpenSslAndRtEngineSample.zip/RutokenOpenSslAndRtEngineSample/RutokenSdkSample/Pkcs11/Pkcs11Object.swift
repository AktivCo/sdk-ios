//
//  Pkcs11Object.swift
//  RutokenSdkSample
//
//  Created by Усман Туркаев on 10.02.2025.
//

import Foundation

struct Pkcs11Object: @unchecked Sendable {
    fileprivate let object: CK_OBJECT_HANDLE
    fileprivate let session: CK_SESSION_HANDLE

    init(with object: CK_OBJECT_HANDLE, _ session: CK_SESSION_HANDLE) {
        self.object = object
        self.session = session
    }

    func getValue(forAttr attrType: Pkcs11DataAttribute) async throws -> Data {
        let size = try await Pkcs11Template()
            .add(attr: attrType)
            .withCkTemplate {
                let rv = await Pkcs11.GetAttributeValue(session, object, &$0, CK_ULONG($0.count))
                guard rv == CKR_OK else {
                    throw Pkcs11Error.error(rv: rv)
                }

                return Int($0[0].ulValueLen)
        }

        return try await Pkcs11Template()
            .add(attr: attrType, value: Data(repeating: 0, count: size))
            .withCkTemplate {
                let rv = await Pkcs11.GetAttributeValue(session, object, &$0, CK_ULONG($0.count))
                guard rv == CKR_OK else {
                    throw Pkcs11Error.error(rv: rv)
                }

                return Data(buffer: UnsafeBufferPointer(start: $0[0].pValue.assumingMemoryBound(to: UInt8.self),
                                                        count: Int($0[0].ulValueLen)))
        }
    }

    func delete() async throws(Pkcs11Error) {
        let rv = await Pkcs11.DestroyObject(session, object)
        guard rv == CKR_OK else {
            throw .error(rv: rv)
        }
    }
}

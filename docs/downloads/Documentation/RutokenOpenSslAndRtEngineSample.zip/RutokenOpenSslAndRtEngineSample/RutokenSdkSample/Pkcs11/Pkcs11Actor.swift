//
//  Pkcs11Actor.swift
//  RutokenSdkSample
//
//  Created by Усман Туркаев on 24.01.2025.
//

@globalActor actor WfseActor: GlobalActor {
    static let shared = WfseActor()
}

@globalActor actor Pkcs11Actor: GlobalActor {
    static let shared = Pkcs11Actor()
}

extension CK_ATTRIBUTE: @unchecked Sendable {}

struct Pkcs11 {
    private init() {}

    @discardableResult
    @WfseActor static func WaitForSlotEvent(_ flags: CK_FLAGS,
                                            _ pSlot: CK_SLOT_ID_PTR!,
                                            _ pReserved: CK_VOID_PTR!) -> CK_RV {
        return C_WaitForSlotEvent(flags, pSlot, pReserved)
    }

    @discardableResult
    @Pkcs11Actor static func Initialize(_ pInitArgs: CK_VOID_PTR!) -> CK_RV {
        return C_Initialize(pInitArgs)
    }

    @discardableResult
    @Pkcs11Actor static func Finalize(_ pReserved: CK_VOID_PTR!) -> CK_RV {
        return C_Finalize(pReserved)
    }

    @discardableResult
    @Pkcs11Actor static func GetSlotList(_ tokenPresent: CK_BBOOL,
                                         _ pSlotList: CK_SLOT_ID_PTR!,
                                         _ pulCount: CK_ULONG_PTR!) -> CK_RV {
        return C_GetSlotList(tokenPresent, pSlotList, pulCount)
    }

    @discardableResult
    @Pkcs11Actor static func GetSlotInfo(_ slotID: CK_SLOT_ID,
                                         _ pInfo: CK_SLOT_INFO_PTR!) -> CK_RV {
        return C_GetSlotInfo(slotID, pInfo)
    }

    @discardableResult
    @Pkcs11Actor static func GetTokenInfo(_ slotID: CK_SLOT_ID,
                                          _ pInfo: CK_TOKEN_INFO_PTR!) -> CK_RV {
        return C_GetTokenInfo(slotID, pInfo)
    }

    @discardableResult
    @Pkcs11Actor static func GetAttributeValue(_ hSession: CK_SESSION_HANDLE,
                                               _ hObject: CK_OBJECT_HANDLE,
                                               _ pTemplate: CK_ATTRIBUTE_PTR!,
                                               _ ulCount: CK_ULONG) -> CK_RV {
        return C_GetAttributeValue(hSession, hObject, pTemplate, ulCount)
    }

    @discardableResult
    @Pkcs11Actor static func DestroyObject(_ hSession: CK_SESSION_HANDLE,
                                           _ hObject: CK_OBJECT_HANDLE) -> CK_RV {
        return C_DestroyObject(hSession, hObject)
    }

    @discardableResult
    @Pkcs11Actor static func SignInit(_ hSession: CK_SESSION_HANDLE,
                                      _ pMechanism: CK_MECHANISM_PTR!,
                                      _ hKey: CK_OBJECT_HANDLE) -> CK_RV {
        return C_SignInit(hSession, pMechanism, hKey)
    }

    @discardableResult
    @Pkcs11Actor static func Sign(_ hSession: CK_SESSION_HANDLE,
                                  _ pData: CK_BYTE_PTR!,
                                  _ ulDataLen: CK_ULONG,
                                  _ pSignature: CK_BYTE_PTR!,
                                  _ pulSignatureLen: CK_ULONG_PTR!) -> CK_RV {
        return C_Sign(hSession, pData, ulDataLen, pSignature, pulSignatureLen)
    }

    @discardableResult
    @Pkcs11Actor static func OpenSession(_ slotID: CK_SLOT_ID,
                                         _ flags: CK_FLAGS,
                                         _ pApplication: CK_VOID_PTR!,
                                         _ Notify: CK_NOTIFY!,
                                         _ phSession: CK_SESSION_HANDLE_PTR!) -> CK_RV {
        return C_OpenSession(slotID, flags, pApplication, Notify, phSession)
    }

    @discardableResult
    @Pkcs11Actor static func Login(_ hSession: CK_SESSION_HANDLE,
                                   _ userType: CK_USER_TYPE,
                                   _ pPin: CK_UTF8CHAR_PTR!,
                                   _ ulPinLen: CK_ULONG) -> CK_RV {
        return C_Login(hSession, userType, pPin, ulPinLen)
    }

    @discardableResult
    @Pkcs11Actor static func Logout(_ hSession: CK_SESSION_HANDLE) -> CK_RV {
        return C_Logout(hSession)
    }

    @discardableResult
    @Pkcs11Actor static func GenerateKeyPair(_ hSession: CK_SESSION_HANDLE,
                                             _ pMechanism: CK_MECHANISM_PTR!,
                                             _ pPublicKeyTemplate: CK_ATTRIBUTE_PTR!,
                                             _ ulPublicKeyAttributeCount: CK_ULONG,
                                             _ pPrivateKeyTemplate: CK_ATTRIBUTE_PTR!,
                                             _ ulPrivateKeyAttributeCount: CK_ULONG,
                                             _ phPublicKey: CK_OBJECT_HANDLE_PTR!,
                                             _ phPrivateKey: CK_OBJECT_HANDLE_PTR!) -> CK_RV {
        return C_GenerateKeyPair(hSession,
                                 pMechanism,
                                 pPublicKeyTemplate,
                                 ulPublicKeyAttributeCount,
                                 pPrivateKeyTemplate,
                                 ulPrivateKeyAttributeCount,
                                 phPublicKey,
                                 phPrivateKey)
    }

    @discardableResult
    @Pkcs11Actor static func FindObjectsInit(_ hSession: CK_SESSION_HANDLE,
                                             _ pTemplate: CK_ATTRIBUTE_PTR!,
                                             _ ulCount: CK_ULONG) -> CK_RV {
        return C_FindObjectsInit(hSession, pTemplate, ulCount)
    }

    @discardableResult
    @Pkcs11Actor static func FindObjects(_ hSession: CK_SESSION_HANDLE,
                                         _ phObject: CK_OBJECT_HANDLE_PTR!,
                                         _ ulMaxObjectCount: CK_ULONG,
                                         _ pulObjectCount: CK_ULONG_PTR!) -> CK_RV {
        return C_FindObjects(hSession, phObject, ulMaxObjectCount, pulObjectCount)
    }

    @discardableResult
    @Pkcs11Actor static func FindObjectsFinal(_ hSession: CK_SESSION_HANDLE) -> CK_RV {
        return C_FindObjectsFinal(hSession)
    }
}

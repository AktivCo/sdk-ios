//
//  Pkcs11Error.swift
//  RutokenSdkSample
//
//  Created by Усман Туркаев on 01.02.2025.
//

enum Pkcs11Error: Error, Equatable {
    case internalError(func: String = #function, line: UInt = #line, rv: UInt? = nil)
    case incorrectPin
    case lockedPin

    var description: String {
        switch self {
        case .internalError(let funcName, let line, let rv):
            return "\(funcName):\(line)\(rv.map { String(format: ":0x%02X", $0) } ?? "")"
        case .incorrectPin:
            return "Неправильный PIN"
        case .lockedPin:
            return "PIN заблокирован"
        }
    }

    static func error(rv: CK_RV? = nil) -> Pkcs11Error {
        switch rv {
        case CKR_PIN_INCORRECT:
            return .incorrectPin
        case CKR_PIN_LOCKED:
            return .lockedPin
        default:
            return .internalError(rv: rv)
        }
    }
}

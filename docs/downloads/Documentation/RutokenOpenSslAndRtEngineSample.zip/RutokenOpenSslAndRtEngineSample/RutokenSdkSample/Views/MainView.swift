//
//  ContentView.swift
//  RutokenSdkSample
//
//  Created by Никита Девятых on 17.01.2025.
//

import SwiftUI

struct MainView: View {
    @StateObject var viewModel = MainViewModel()
    @State var enterLabel: Bool = false
    @State var label: String = ""
    @State var selectedToken: Pkcs11Token? = nil

    var body: some View {
        NavigationStack {
            VStack {
                List {
                    ForEach(Array(viewModel.tokens.values)) { token in
                        TokenCardView(token: token)
                            .onTapGesture {
                                selectedToken = token
                            }
                    }
                }
                .scrollContentBackground(.hidden)
                MainButton(text: viewModel.isMonitoringEnabled ? "Остановить поиск" : "Начать поиск") {
                    if viewModel.isMonitoringEnabled {
                        viewModel.stopMonitoring()
                    } else {
                        viewModel.startMonitoring()
                    }
                }
                .padding()
            }
            .navigationTitle("Рутокены")
            .navigationDestination(isPresented: Binding(get: { selectedToken != nil },
                                                        set: { if !$0 { deselectToken() }})) {
                if let token = selectedToken {
                    TokenView(token: token)
                }
            }
            .background(.gray.opacity(0.1))
        }
        .alert(viewModel.errorText ?? "",
               isPresented: Binding(get: { viewModel.errorText != nil },
                                    set: { if !$0 { viewModel.setError(nil) } })) {
            Button("OK", role: .cancel) { viewModel.setError(nil) }
        }
        .onChange(of: viewModel.tokens) {
            guard let token = selectedToken else { return }
            if viewModel.tokens[token.slot] != token {
                deselectToken()
            }
        }
    }

    func deselectToken() {
        guard let token = selectedToken else { return }
        selectedToken = nil
        Task.detached {
            await token.logout()
        }
    }
}

//
//  TokenView.swift
//  RutokenSdkSample
//
//  Created by Усман Туркаев on 21.02.2025.
//

import SwiftUI

struct TokenView: View {
    @StateObject var viewModel: TokenViewModel
    @State var label: String = ""
    @State var pin: String = "12345678"
    @State var isGenerateKeyPairPressed: Bool = false
    @State var isLoginButtonPressed: Bool = false

    init(token: Pkcs11Token) {
        _viewModel = StateObject(wrappedValue: TokenViewModel(token: token))
    }

    var body: some View {
        VStack {
            if let keyPairs = viewModel.keyPairs {
                if keyPairs.isEmpty {
                    Spacer()
                    Text("На Рутокене нет ни одной ключевой пары")
                        .multilineTextAlignment(.center)
                        .padding()
                    Spacer()
                } else {
                    List {
                        ForEach(Array(keyPairs)) { keyPair in
                            KeyPairView(keyPair: keyPair)
                        }
                        .onDelete { index in
                            viewModel.deleteKeyPair(at: index)
                        }
                    }
                    .scrollContentBackground(.hidden)
                }
                MainButton(text: "Сгенерировать пару") {
                    isGenerateKeyPairPressed = true
                }
                .padding()
            } else {
                Spacer()
                Text("Чтобы увидеть свои ключевые пары, авторизуйтесь")
                    .multilineTextAlignment(.center)
                    .padding()
                Spacer()
                MainButton(text: "Авторизоваться") {
                    isLoginButtonPressed = true
                }
                .padding()
            }
        }
        .navigationTitle(viewModel.token.label)
        .background(.gray.opacity(0.1))
        .alert("Введите метку", isPresented: $isGenerateKeyPairPressed) {
            TextField("Метка", text: $label)
            Button("OK") {
                viewModel.generateKeyPair(label: label)
                label = ""
            }
            .disabled(label.isEmpty)
            Button("Отмена", role: .cancel) {
                label = ""
            }
        }
        .alert("Введите PIN", isPresented: $isLoginButtonPressed) {
            SecureField("PIN", text: $pin)
            Button("OK") {
                viewModel.enumerateKeys(pin: pin)
            }
            Button("Отмена", role: .cancel) {
                pin = "12345678"
            }
        }
        .alert(viewModel.errorText ?? "",
               isPresented: Binding(get: { viewModel.errorText != nil },
                                    set: { if !$0 { viewModel.setError(nil) } })) {
            Button("OK", role: .cancel) { viewModel.setError(nil) }
        }
    }
}

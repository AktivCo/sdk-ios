//
//  KeyPairView.swift
//  RutokenSdkSample
//
//  Created by Усман Туркаев on 12.02.2025.
//

import SwiftUI

struct KeyPairView: View {
    let keyPair: Pkcs11KeyPair

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text("ID ключевой пары")
                .foregroundStyle(.secondary)
                .font(.subheadline)
            Text(keyPair.id)
            Text("Метка")
                .foregroundStyle(.secondary)
                .font(.subheadline)
            Text(keyPair.label)
        }
    }
}

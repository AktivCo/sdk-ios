//
//  TokenCardView.swift
//  RutokenSdkSample
//
//  Created by Усман Туркаев on 27.01.2025.
//

import SwiftUI

struct TokenCardView: View {
    var token: Pkcs11Token

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 10) {
                Text("Имя токена")
                    .foregroundStyle(.secondary)
                    .font(.subheadline)
                Text(token.label)
                Text("Серийный номер")
                    .foregroundStyle(.secondary)
                    .font(.subheadline)
                Text(token.serial)
            }
            Spacer()
            Image(systemName: "chevron.right")
                .foregroundStyle(.secondary)
        }
        .contentShape(Rectangle())
    }
}

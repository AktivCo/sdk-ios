//
//  MainButton.swift
//  RutokenSdkSample
//
//  Created by Усман Туркаев on 10.02.2025.
//

import SwiftUI

struct MainButton: View {
    let text: String
    let action: () -> Void

    var body: some View {
        Button {
            action()
        } label: {
            Text(text)
                .animation(nil)
                .font(.headline)
                .frame(maxWidth: .infinity)
                .frame(height: 40)
        }
        .buttonStyle(.borderedProminent)
    }
}

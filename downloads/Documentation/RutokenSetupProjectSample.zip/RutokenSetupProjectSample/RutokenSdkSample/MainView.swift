//
//  ContentView.swift
//  RutokenSdkSample
//
//  Created by Никита Девятых on 17.01.2025.
//

import SwiftUI

struct MainView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
        }
        .padding()
    }
}

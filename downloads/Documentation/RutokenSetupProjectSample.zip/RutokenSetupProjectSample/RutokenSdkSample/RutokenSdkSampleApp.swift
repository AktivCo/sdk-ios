//
//  RutokenSdkSampleApp.swift
//  RutokenSdkSample
//
//  Created by Никита Девятых on 17.01.2025.
//

import SwiftUI

@main
struct RutokenSdkSampleApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
